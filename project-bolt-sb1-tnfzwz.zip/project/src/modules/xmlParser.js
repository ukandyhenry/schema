export function parseXML(content) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(content, 'application/xml');
  const parseError = doc.getElementsByTagName('parsererror')[0];
  
  if (parseError) {
    throw new Error(parseError.textContent);
  }
  
  return doc;
}