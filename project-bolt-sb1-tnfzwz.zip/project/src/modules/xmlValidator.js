import { parseXML } from './xmlParser.js';
import { validateNamespaces } from './namespaceValidator.js';
import { validateElements } from './elementValidator.js';

export async function validateXMLSchema(xmlContent, xsdContent) {
  try {
    // Parse both documents
    const xmlDoc = parseXML(xmlContent);
    const xsdDoc = parseXML(xsdContent);

    // Validate XML structure
    const structureValidation = validateStructure(xmlDoc, xsdDoc);
    if (!structureValidation.valid) {
      return {
        success: false,
        message: 'XML Structure Validation Failed',
        details: structureValidation.errors.join('\n')
      };
    }

    // Validate namespaces
    const namespaceValidation = validateNamespaces(xmlDoc, xsdDoc);
    if (!namespaceValidation.valid) {
      return {
        success: false,
        message: 'XML Namespace Validation Failed',
        details: namespaceValidation.errors.join('\n')
      };
    }

    // Validate elements
    const elementValidation = validateElements(xmlDoc, xsdDoc);
    if (!elementValidation.valid) {
      return {
        success: false,
        message: 'XML Element Validation Failed',
        details: elementValidation.errors.join('\n')
      };
    }

    return {
      success: true,
      message: 'XML is valid according to the schema!',
      details: ''
    };
  } catch (error) {
    return {
      success: false,
      message: 'Validation error',
      details: error.message
    };
  }
}

function validateStructure(xmlDoc, xsdDoc) {
  const errors = [];
  const rootElement = xmlDoc.documentElement;
  const schemaElement = xsdDoc.documentElement;

  // Check if root element matches schema
  if (schemaElement.getAttribute('targetNamespace')) {
    const targetNS = schemaElement.getAttribute('targetNamespace');
    if (rootElement.namespaceURI !== targetNS) {
      errors.push(`Root element namespace "${rootElement.namespaceURI}" does not match schema target namespace "${targetNS}"`);
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}