import { XMLSchema } from 'xmlschema';

export async function validateXMLSchema(xmlContent, xsdContent) {
  try {
    // Parse XML and XSD using the browser's DOMParser
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlContent, 'application/xml');
    const xsdDoc = parser.parseFromString(xsdContent, 'application/xml');

    // Check for XML parsing errors
    const xmlParseError = xmlDoc.getElementsByTagName('parsererror')[0];
    if (xmlParseError) {
      return {
        success: false,
        message: 'XML Parse Error',
        details: xmlParseError.textContent
      };
    }

    // Check for XSD parsing errors
    const xsdParseError = xsdDoc.getElementsByTagName('parsererror')[0];
    if (xsdParseError) {
      return {
        success: false,
        message: 'XSD Schema Parse Error',
        details: xsdParseError.textContent
      };
    }

    // Create schema validator
    const schema = new XMLSchema(xsdDoc);
    
    // Validate XML against schema
    const validationResult = schema.validate(xmlDoc);
    
    if (validationResult.length === 0) {
      return {
        success: true,
        message: 'XML is valid according to the schema!'
      };
    } else {
      return {
        success: false,
        message: 'XML validation failed:',
        details: validationResult.map(error => error.message).join('\n')
      };
    }
  } catch (error) {
    return {
      success: false,
      message: 'Validation error:',
      details: error.message
    };
  }
}