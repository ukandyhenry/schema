export function showResult(message, success, details = '') {
  const resultDiv = document.getElementById('result');
  resultDiv.textContent = message + (details ? '\n\n' + details : '');
  resultDiv.className = 'result ' + (success ? 'success' : 'error');
}