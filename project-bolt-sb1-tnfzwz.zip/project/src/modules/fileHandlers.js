import { showResult } from './ui.js';

export function setupFileHandlers() {
  window.handleFileInput = handleFileSelect;
}

function handleFileSelect(type) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = type === 'xml' ? '.xml' : '.xsd';
  
  input.onchange = async (e) => {
    try {
      const file = e.target.files[0];
      const content = await file.text();
      document.getElementById(`${type}Input`).value = content;
    } catch (error) {
      showResult(`Error loading file: ${error.message}`, false);
    }
  };
  
  input.click();
}