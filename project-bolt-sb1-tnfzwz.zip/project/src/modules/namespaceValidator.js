export function validateNamespaces(xmlDoc, xsdDoc) {
  const errors = [];
  const xmlNamespaces = collectNamespaces(xmlDoc.documentElement);
  const schemaNamespaces = getSchemaNamespaces(xsdDoc);

  // Check if all required namespaces are present
  for (const ns of schemaNamespaces) {
    if (ns.required && !xmlNamespaces.has(ns.uri)) {
      errors.push(`Required namespace "${ns.uri}" is missing`);
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

function collectNamespaces(element, namespaces = new Set()) {
  // Add element's namespace
  if (element.namespaceURI) {
    namespaces.add(element.namespaceURI);
  }

  // Add namespaces from attributes
  for (const attr of element.attributes) {
    if (attr.namespaceURI) {
      namespaces.add(attr.namespaceURI);
    }
  }

  // Recursively process child elements
  for (const child of element.children) {
    collectNamespaces(child, namespaces);
  }

  return namespaces;
}

function getSchemaNamespaces(xsdDoc) {
  const namespaces = [];
  const schema = xsdDoc.documentElement;

  // Get target namespace
  const targetNS = schema.getAttribute('targetNamespace');
  if (targetNS) {
    namespaces.push({ uri: targetNS, required: true });
  }

  // Get imported namespaces
  const imports = schema.getElementsByTagName('import');
  for (const imp of imports) {
    const ns = imp.getAttribute('namespace');
    if (ns) {
      namespaces.push({ uri: ns, required: true });
    }
  }

  return namespaces;
}