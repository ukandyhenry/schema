export function handleFileSelect(type) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = type === 'xml' ? '.xml' : '.xsd';
  
  input.onchange = async (e) => {
    try {
      const file = e.target.files[0];
      const content = await file.text();
      document.getElementById(`${type}Input`).value = content;
    } catch (error) {
      showResult(`Error loading file: ${error.message}`, false);
    }
  };
  
  input.click();
}

export function showResult(message, success, details = '') {
  const resultDiv = document.getElementById('result');
  resultDiv.textContent = message + (details ? '\n\n' + details : '');
  resultDiv.className = 'result ' + (success ? 'success' : 'error');
}