import { initializeValidation } from './modules/validation.js';
import { setupFileHandlers } from './modules/fileHandlers.js';

// Initialize IPC communication with Electron
window.electron = require('electron');

document.addEventListener('DOMContentLoaded', () => {
  initializeValidation();
  setupFileHandlers();
});