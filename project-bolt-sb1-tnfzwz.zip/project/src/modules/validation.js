export function initializeValidation() {
  const validateBtn = document.getElementById('validateBtn');
  
  validateBtn.addEventListener('click', async () => {
    const xmlContent = document.getElementById('xmlInput').value;
    const xsdContent = document.getElementById('xsdInput').value;

    if (!xmlContent || !xsdContent) {
      showResult('Please provide both XML and XSD content', false);
      return;
    }

    try {
      const result = await window.electron.ipcRenderer.invoke('validate-xml', {
        xmlContent,
        xsdContent
      });
      
      showResult(result.message, result.success, result.details);
    } catch (error) {
      showResult('Validation error: ' + error.message, false);
    }
  });
}