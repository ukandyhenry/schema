const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1024,
    height: 768,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  // In development, load from Vite dev server
  if (process.env.NODE_ENV === 'development') {
    win.loadURL('http://localhost:5173');
  } else {
    // In production, load from built files
    win.loadFile(path.join(__dirname, '../dist/index.html'));
  }
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Handle XML validation
ipcMain.handle('validate-xml', async (event, { xmlContent, xsdContent }) => {
  try {
    const { DOMParser } = require('xmldom');
    const parser = new DOMParser();
    
    // Parse XML and XSD
    const xmlDoc = parser.parseFromString(xmlContent, 'text/xml');
    const xsdDoc = parser.parseFromString(xsdContent, 'text/xml');
    
    // Perform validation using the existing validation logic
    const result = await validateXMLSchema(xmlDoc, xsdDoc);
    return result;
  } catch (error) {
    return {
      success: false,
      message: 'Validation error',
      details: error.message
    };
  }
});