const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs').promises;
const libxmlXsd = require('libxml-xsd');
const { promisify } = require('util');

const validateXML = promisify(libxmlXsd.validate);
const parseXsd = promisify(libxmlXsd.parse);

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  win.loadFile('index.html');
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

ipcMain.handle('validate-xml', async (event, { xmlContent, xsdContent }) => {
  try {
    const schema = await parseXsd(xsdContent);
    await validateXML(schema, xmlContent);
    return { success: true, message: 'XML is valid!' };
  } catch (error) {
    return { 
      success: false, 
      message: `Validation failed: ${error.message}`,
      details: error.toString()
    };
  }
});