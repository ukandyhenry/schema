export function validateElements(xmlDoc, xsdDoc) {
  const errors = [];
  const schema = xsdDoc.documentElement;
  const rootElement = xmlDoc.documentElement;

  // Get all element definitions from schema
  const elementDefs = getElementDefinitions(schema);
  
  // Validate root element
  validateElement(rootElement, elementDefs, errors);

  return {
    valid: errors.length === 0,
    errors
  };
}

function getElementDefinitions(schema) {
  const defs = new Map();
  const elements = schema.getElementsByTagName('element');

  for (const element of elements) {
    const name = element.getAttribute('name');
    if (name) {
      defs.set(name, {
        type: element.getAttribute('type'),
        minOccurs: element.getAttribute('minOccurs') || '1',
        maxOccurs: element.getAttribute('maxOccurs') || '1'
      });
    }
  }

  return defs;
}

function validateElement(element, elementDefs, errors) {
  const elementName = element.localName;
  const def = elementDefs.get(elementName);

  if (!def) {
    errors.push(`Unknown element "${elementName}"`);
    return;
  }

  // Validate type if specified
  if (def.type) {
    validateElementType(element, def.type, errors);
  }

  // Recursively validate child elements
  for (const child of element.children) {
    validateElement(child, elementDefs, errors);
  }
}

function validateElementType(element, type, errors) {
  // Basic type validation
  switch (type) {
    case 'xs:string':
      if (element.textContent.trim() === '') {
        errors.push(`Element "${element.localName}" of type string cannot be empty`);
      }
      break;
    case 'xs:integer':
      if (!/^\d+$/.test(element.textContent)) {
        errors.push(`Element "${element.localName}" must be an integer`);
      }
      break;
    case 'xs:decimal':
      if (!/^\d*\.?\d+$/.test(element.textContent)) {
        errors.push(`Element "${element.localName}" must be a decimal number`);
      }
      break;
    case 'xs:boolean':
      if (!['true', 'false', '1', '0'].includes(element.textContent.toLowerCase())) {
        errors.push(`Element "${element.localName}" must be a boolean value`);
      }
      break;
  }
}