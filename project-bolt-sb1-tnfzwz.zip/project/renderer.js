async function loadFile(type) {
  try {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = type === 'xml' ? '.xml' : '.xsd';
    
    input.onchange = async (e) => {
      const file = e.target.files[0];
      const content = await file.text();
      document.getElementById(`${type}Input`).value = content;
    };
    
    input.click();
  } catch (error) {
    showResult(`Error loading file: ${error.message}`, false);
  }
}

async function validateXML() {
  const xmlContent = document.getElementById('xmlInput').value;
  const xsdContent = document.getElementById('xsdInput').value;

  if (!xmlContent || !xsdContent) {
    showResult('Please provide both XML and XSD content', false);
    return;
  }

  try {
    const result = await window.electron.ipcRenderer.invoke('validate-xml', {
      xmlContent,
      xsdContent
    });

    showResult(result.message, result.success);
  } catch (error) {
    showResult(`Error: ${error.message}`, false);
  }
}

function showResult(message, success) {
  const resultDiv = document.getElementById('result');
  resultDiv.textContent = message;
  resultDiv.className = 'result ' + (success ? 'success' : 'error');
}